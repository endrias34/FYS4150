

import numpy as np
import matplotlib.pyplot as plt



f0 = np.array([x.split() for x in open("parallel_check0.txt", "r")][1:]).T[1:] 	# Parallel 2x2
f1 = np.array([x.split() for x in open("parallel_check1.txt", "r")][1:]).T[1:] 	# Parallel 8x8
f2 = np.array([x.split() for x in open("parallel_check2.txt", "r")][1:]).T[1:] 	# Parallel 20x20



s00 = np.array([x.split() for x in open("3parallel_check0.txt", "r")][1:]).T[1:]	# Single Thread 2x2	250000
s01 = np.array([x.split() for x in open("3parallel_check1.txt", "r")][1:]).T[1:]	# Single Thread 8x8	250000
s02 = np.array([x.split() for x in open("3parallel_check2.txt", "r")][1:]).T[1:]	# Single Thread 20x20	250000
s10 = np.array([x.split() for x in open("4parallel_check0.txt", "r")][1:]).T[1:]	# Single Thread 2x2	500000
s11 = np.array([x.split() for x in open("4parallel_check1.txt", "r")][1:]).T[1:]	# Single Thread 8x8	500000
s12 = np.array([x.split() for x in open("4parallel_check2.txt", "r")][1:]).T[1:]	# Single Thread 20x20	500000
s20 = np.array([x.split() for x in open("5parallel_check0.txt", "r")][1:]).T[1:]	# Single Thread 2x2 	750000
s21 = np.array([x.split() for x in open("5parallel_check1.txt", "r")][1:]).T[1:]	# Single Thread 8x8	750000
s22 = np.array([x.split() for x in open("5parallel_check2.txt", "r")][1:]).T[1:]	# Single Thread 20x20	750000
s30 = np.array([x.split() for x in open("2parallel_check0.txt", "r")][1:]).T[1:]	# Single Thread 2x2 	1000000
s31 = np.array([x.split() for x in open("2parallel_check1.txt", "r")][1:]).T[1:]	# Single Thread 8x8	1000000
s32 = np.array([x.split() for x in open("2parallel_check2.txt", "r")][1:]).T[1:]	# Single Thread 20x20	1000000



Strings = ["Mean Energy", "Energy Squared", "Absolute Magnetization", "Magnetization Squared", "Heat capacity", "Magnetic susceptibility"]

# For 2x2

for k in range(6):
  f0_Mean = [float(x) for x in f0[k]]
  s00_Mean = [float(x) for x in s00[k]]
  s10_Mean = [float(x) for x in s10[k]]
  s20_Mean = [float(x) for x in s20[k]]
  s30_Mean = [float(x) for x in s30[k]]


  data = [f0_Mean, s30_Mean, s20_Mean, s10_Mean, s00_Mean] 
    
  fig = plt.figure(figsize =(10, 7)) 
  ax = fig.add_subplot(111) 
    
  # Creating axes instance 
  bp = ax.boxplot(data, patch_artist = True, 
                  notch ='True', vert = 0) 
    
  colors = ['#0000FF', '#00FF00',  
            '#FFFF00', '#F0F0F0',
  	        '#000000'] 
    
  for patch, color in zip(bp['boxes'], colors): 
      patch.set_facecolor(color) 
    
  # changing color and linewidth of 
  # whiskers 
  for whisker in bp['whiskers']: 
      whisker.set(color ='#8B008B', 
                  linewidth = 1.5, 
                  linestyle =":") 
    
  # changing color and linewidth of 
  # caps 
  for cap in bp['caps']: 
      cap.set(color ='#8B008B', 
              linewidth = 2) 
    
  # changing color and linewidth of 
  # medians 
  for median in bp['medians']: 
      median.set(color ='red', 
                 linewidth = 3) 
    
  # changing style of fliers 
  for flier in bp['fliers']: 
      flier.set(marker ='D', 
                color ='#e7298a', 
                alpha = 0.5) 
        
  # x-axis labels 
  ax.set_yticklabels(['250k 4 Threads', '1000k 1 thread',  
                      '750k 1 thread', '500k 1 thread',
                      '250k 1 thread']) 
    
  # Adding title  
  plt.title(Strings[k]+" 2x2 Lattice", fontsize= 20) 
    
  # Removing top axes and right axes 
  ax.get_xaxis().tick_bottom() 
  ax.get_yaxis().tick_left() 
        
  ax.tick_params(axis = 'both', which = 'major', labelsize = 16)
  ax.tick_params(axis = 'both', which = 'minor', labelsize = 16)

  # show plot 
  plt.show(bp) 



# For 8x8

for k in range(6):
  f0_Mean = [float(x) for x in f1[k]]
  s00_Mean = [float(x) for x in s01[k]]
  s10_Mean = [float(x) for x in s11[k]]
  s20_Mean = [float(x) for x in s21[k]]
  s30_Mean = [float(x) for x in s31[k]]


  data = [f0_Mean, s30_Mean, s20_Mean, s10_Mean, s00_Mean] 
    
  fig = plt.figure(figsize =(10, 7)) 
  ax = fig.add_subplot(111) 
    
  # Creating axes instance 
  bp = ax.boxplot(data, patch_artist = True, 
                  notch ='True', vert = 0) 
    
  colors = ['#0000FF', '#00FF00',  
            '#FFFF00', '#F0F0F0',
            '#000000'] 
    
  for patch, color in zip(bp['boxes'], colors): 
      patch.set_facecolor(color) 
    
  # changing color and linewidth of 
  # whiskers 
  for whisker in bp['whiskers']: 
      whisker.set(color ='#8B008B', 
                  linewidth = 1.5, 
                  linestyle =":") 
    
  # changing color and linewidth of 
  # caps 
  for cap in bp['caps']: 
      cap.set(color ='#8B008B', 
              linewidth = 2) 
    
  # changing color and linewidth of 
  # medians 
  for median in bp['medians']: 
      median.set(color ='red', 
                 linewidth = 3) 
    
  # changing style of fliers 
  for flier in bp['fliers']: 
      flier.set(marker ='D', 
                color ='#e7298a', 
                alpha = 0.5) 
        
  # x-axis labels 
  ax.set_yticklabels(['250k 4 Threads', '1000k 1 thread',  
                      '750k 1 thread', '500k 1 thread',
                      '250k 1 thread']) 
    
  # Adding title  
  plt.title(Strings[k]+" 8x8 Lattice", fontsize= 20) 
    
  # Removing top axes and right axes 
  ax.get_xaxis().tick_bottom() 
  ax.get_yaxis().tick_left() 
        
  ax.tick_params(axis = 'both', which = 'major', labelsize = 16)
  ax.tick_params(axis = 'both', which = 'minor', labelsize = 16)

  # show plot 
  plt.show(bp) 




# For 20x20

for k in range(6):
  f0_Mean = [float(x) for x in f2[k]]
  s00_Mean = [float(x) for x in s02[k]]
  s10_Mean = [float(x) for x in s12[k]]
  s20_Mean = [float(x) for x in s22[k]]
  s30_Mean = [float(x) for x in s32[k]]


  data = [f0_Mean, s30_Mean, s20_Mean, s10_Mean, s00_Mean] 
    
  fig = plt.figure(figsize =(10, 7)) 
  ax = fig.add_subplot(111) 
    
  # Creating axes instance 
  bp = ax.boxplot(data, patch_artist = True, 
                  notch ='True', vert = 0) 
    
  colors = ['#0000FF', '#00FF00',  
            '#FFFF00', '#F0F0F0',
            '#000000'] 
    
  for patch, color in zip(bp['boxes'], colors): 
      patch.set_facecolor(color) 
    
  # changing color and linewidth of 
  # whiskers 
  for whisker in bp['whiskers']: 
      whisker.set(color ='#8B008B', 
                  linewidth = 1.5, 
                  linestyle =":") 
    
  # changing color and linewidth of 
  # caps 
  for cap in bp['caps']: 
      cap.set(color ='#8B008B', 
              linewidth = 2) 
    
  # changing color and linewidth of 
  # medians 
  for median in bp['medians']: 
      median.set(color ='red', 
                 linewidth = 3) 
    
  # changing style of fliers 
  for flier in bp['fliers']: 
      flier.set(marker ='D', 
                color ='#e7298a', 
                alpha = 0.5) 
        
  # x-axis labels 
  ax.set_yticklabels(['250k 4 Threads', '1000k 1 thread',  
                      '750k 1 thread', '500k 1 thread',
                      '250k 1 thread']) 
    
  # Adding title  
  plt.title(Strings[k]+" 20x20 Lattice", fontsize= 20) 
    
  # Removing top axes and right axes 
  ax.get_xaxis().tick_bottom() 
  ax.get_yaxis().tick_left() 
        
  ax.tick_params(axis = 'both', which = 'major', labelsize = 16)
  ax.tick_params(axis = 'both', which = 'minor', labelsize = 16)

  # show plot 
  plt.show(bp) 




